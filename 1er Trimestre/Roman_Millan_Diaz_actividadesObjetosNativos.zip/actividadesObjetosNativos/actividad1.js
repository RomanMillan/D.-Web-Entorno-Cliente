//1
window.moveTo(20,9);
window.resizeBy(20,90);