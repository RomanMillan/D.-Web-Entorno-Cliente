console.log(document.anchors);
console.log(document.images);
console.log(document.forms);
console.log(document.links);
console.log(document.embeds);