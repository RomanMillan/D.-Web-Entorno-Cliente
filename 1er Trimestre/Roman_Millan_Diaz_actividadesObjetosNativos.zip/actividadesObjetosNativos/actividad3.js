console.log(location.port);
console.log(location.hash);
console.log(location.href);
console.log(location.protocol);
console.log(location.search);
console.log(location.pathname);
console.log(location.host);
console.log(location.hostname);