console.log(navigator.getBattery());
console.log(navigator.appName);
console.log(navigator.javaEnabled);
console.log(navigator.languages);
console.log(navigator.onLine);