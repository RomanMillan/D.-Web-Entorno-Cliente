console.log(screen.availLeft);
console.log(screen.height);
console.log(screen.colorDepth);
console.log(screen.width);
