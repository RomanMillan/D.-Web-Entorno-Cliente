
const MONTHS = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre'
];

const DAYS = [
    'Domingo',
    'Lunes',
    'Martes',
    'Miércoles',
    'Jueves',
    'Viernes',
    'Sábado'
];

//cogemos el mes que ha escrito el usuario en el input
let month = document.querySelector('#month');

//obtenemos el año que ha insertado el usuario
let year = document.querySelector('#year');

document.querySelector('#botonCalendario').addEventListener('click', mostrarCalendario);

/*  Obtenemos la posición del mes quitándole al valor del campo los espacios, 
 conviertiendo la primera en mayúsculas y el resto en minúsculas
 */
function mostrarCalendario() {
    //buscamos la posicion del mes pasado por el usuario
    let monthIndex = MONTHS.indexOf(month.value.charAt(0).toUpperCase() + month.value.slice(1).trim().toLowerCase());

    // Detectamos si el mes es incorrecto y si es correcto obtenemos los datos
    if (monthIndex == -1) {                                                         
        alert('Mes incorrecto');
    }else {
        // Obtenemos el número de días que tiene el mes pasándole por parámetros el día 0
        let dias = new Date(year.value, monthIndex, 0).getDate();           
        // Creamos una nueva fecha comenzando por el primer día
        let nuevaFecha = new Date(year.value, monthIndex, 1);               
        // Creamos una lista desordenada
        let lista = document.createElement('ul');                           

         // Recorremos los días que tenga el mes para ir creando un elemento por cada uno
        for (let i = 1; i <= dias + 1; i++) {                                                          
            // Establecemos dicho día
            nuevaFecha.setDate(i);
            // Creamos un li por cada día                                                                      
            let newLi = document.createElement('li'); 
            // Creamos el nodo de texto y lo añadimos al nuevo li                                                  
            newLi.appendChild(document.createTextNode(`${i} (${DAYS[nuevaFecha.getDay()]})`));          
             // Añadimos a la lista el nuevo li
            lista.appendChild(newLi);                                                                  
        }
        // Añadimos la lista a la caja de la función
        document.querySelector('#box-2').appendChild(lista);                                            
    }
}
