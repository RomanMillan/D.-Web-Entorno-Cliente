

setInterval(() => {
    // Creamos una fecha con el momento actual

        let nuevaFecha = new Date();

    // Actualizamos los datos cada 1s

        horaActual.innerText = `${((nuevaFecha.getHours() < 10) ? '0': '') + nuevaFecha.getHours()}:${((nuevaFecha.getMinutes() < 10) ? '0':'') + nuevaFecha.getMinutes()}:${((nuevaFecha.getSeconds() < 10) ? '0': '') + nuevaFecha.getSeconds()}`;
    }, 1000)


    
    // Obtenemos el audio con el sonido de la alarma

    //const music = new Audio('./assets/alarma.mp3');

    // Indicamos que se reproduzca en bucle

        //music.loop = true;

    // Añadimos un evento de cambio al input datatime para que al cambiar esté disponible el botón

        horaAlarma.addEventListener('change', () => {
            alarmaSwitch.disabled = false;
        });

// Función crearAlarma: Activa la alarma al introducir una fecha en el campo

    function crearAlarma() {
        // Crea una nueva fecha con el valor
        let horaIntroducida = new Date(document.getElementById('horaAlarma').value);     
        // Deshabilitamos el botón de activar alarma       
        alarmaSwitch.disabled = true;    
        // Establecemos la alarma, para ello, el tiempo de espera será la diferencia de los milisegundos de la hora a sonar menos la hora actual                                                       
        establecerAlarma(horaIntroducida.getTime() - new Date().getTime());                     
    }

// Función establecer alarma : Esta función recibe X milisegundos por parámetros y hará sonar la alarma al pasar esos segundos

    function establecerAlarma(milisegundos) {
        setTimeout(() => {
              // Hacemos sonar la alarma
            sonarAlarma();                                                                    
        }, milisegundos)
    }

// Función sonar alarma

    function sonarAlarma() {
         // Establecemos la reproducción del sonido al segundo 0
        music.currentTime = 0;   
        // Reproducimos el sonido                                                              
        music.play();                                                                           
        // Reproducimos el sonido 10 milisegundos después
        setTimeout(() => {         
            // Preguntamos al usuario si desea posponer o apagar                                                            
            let respuesta = prompt('La alarma ha sonado (Posponer o Apagar)');                  
            // Pausamos el sonido
            music.pause();          
            // Si la respuesta es posponer ...                                                           
            if (respuesta.trim().toUpperCase() == 'POSPONER') {    
                // Establecemos una alarma para dentro de 2 minutos (120000 milisegundos)                             
                establecerAlarma(120000);                                                           
            }
            else {
                 // Habilitamos el botón 
                alarmaSwitch.disabled = false;                                                 
            }
        }, 5000);
    }