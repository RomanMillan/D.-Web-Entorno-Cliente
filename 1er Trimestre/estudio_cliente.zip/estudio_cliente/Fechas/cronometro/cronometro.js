
let cronometro = document.querySelector('#cronometro');

setInterval(() => {
    // Creamos una fecha con el momento actual
        let nuevaFecha = new Date();                                                                        
    // Actualizamos los datos cada 1s
        cronometro.innerText = `Hoy es ${((nuevaFecha.getDate() < 10) ? '0':'') + nuevaFecha.getDate()}-${((nuevaFecha.getMonth() < 10) ? '0': '') + nuevaFecha.getMonth()}-${nuevaFecha.getFullYear()} y son las ${((nuevaFecha.getHours() < 10) ? '0':'') + nuevaFecha.getHours()}:${((nuevaFecha.getMinutes() < 10) ? '0':'') + nuevaFecha.getMinutes()}:${((nuevaFecha.getSeconds() < 10)? '0':'') + nuevaFecha.getSeconds()} horas.`;     
}, 1000)