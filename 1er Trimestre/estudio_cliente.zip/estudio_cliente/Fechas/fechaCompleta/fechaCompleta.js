
const MONTHS = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre'
];

const DAYS = [
    'Domingo',
    'Lunes',
    'Martes',
    'Miércoles',
    'Jueves',
    'Viernes',
    'Sábado'
];

//funcion para añadirle un 0 delante cuando los minutos sean menos de  10
function minutos(minuts){
    if (minuts<10){
        minuts = '0'+minuts;
    }
    return minuts;
}

//obtenemos el input de fecha y le agregamos un escuchador (addEventLinstener)
//y que se active el metodo actualizarHora cuando cambie el input.
document.querySelector('#campoDataTime').addEventListener('change', actualizarHora); 

//funcion para mostrar la fecha completa en un formato modificado a nuestro gusto
function actualizarHora() {
    // Creamos una nueva fecha con el valor introducido
    let nuevaFecha = new Date(document.querySelector('#campoDataTime').value); 
    // Mostramos la fecha obteniendo cada valor                                                                                                                                                             
    fechaResultado.innerText = `Hoy es ${DAYS[nuevaFecha.getDay()]}, ${nuevaFecha.getDate()} 
    de ${MONTHS[nuevaFecha.getMonth()]} de ${nuevaFecha.getFullYear()} y son 
    las ${nuevaFecha.getHours()}:${minutos(nuevaFecha.getMinutes())} horas.`;
}