let mes2 = document.querySelector('#mes2');

mes2.addEventListener('change', (e)=>{
    let fecha2 = new Date(e.target.value);
    let mes2 = fecha2.getMonth();
    let calendario = document.getElementById('calendario');
    //calendario.textContent = `${meses[fecha2.getMonth()]} de ${fecha2.getFullYear()}`
    while(fecha2.getMonth()==mes2){
        calendario.textContent += `${fecha2.getDate()}`

        fecha2.setDate(fecha2.getDate()+1);
    }
});