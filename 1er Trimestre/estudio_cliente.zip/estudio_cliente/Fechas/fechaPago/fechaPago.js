const MONTHS = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre'
];

const DAYS = [
    'Domingo',
    'Lunes',
    'Martes',
    'Miércoles',
    'Jueves',
    'Viernes',
    'Sábado'
];

document.querySelector('#pagoRetrasado').addEventListener('click', calcularFechapago);  
function calcularFechapago () {
    // Comprobamos si se ha introducido un día positivo
    if (diasDeRetraso.value > 0) { 
        // Creamos una fecha con el valor introducido                                                                                                                                                     
        let nuevaFecha = new Date(fecha.value); 
        // Modificamos la fecha, para ello añadimos los días que ha introducido el usuario                                                                                                                                        
        nuevaFecha.setDate(nuevaFecha.getDate() + parseInt(diasDeRetraso.value));         
        // Mostramos el resultado                                                                                              
        pagoRetrasadoResultado.innerHTML = `El pago es el ${DAYS[nuevaFecha.getDay()]}, ${nuevaFecha.getDate()} de ${MONTHS[nuevaFecha.getMonth()]} de ${nuevaFecha.getFullYear()}`;    
    }
    else {
         // Si se ha introducido un valor no válido lo indicamos
        pagoRetrasadoResultado.innerHTML = 'Inserte un número de días a retrasar correcto';                                                                                            
    }
}