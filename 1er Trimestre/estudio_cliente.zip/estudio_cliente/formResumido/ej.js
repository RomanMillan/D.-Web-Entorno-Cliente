const nombreInput = document.querySelector('#nombre')
const form = document.querySelector('#formulario');
console.log(nombreInput)

const checkName = () => {
    let valid = false;
    const min = 3, max = 20;
    const nombre = nombreInput.value;
    if(nombre == ''){
        showError(nombreInput,"El nombre no puede estar en blanco");
    }else if(nombre.length < min || nombre.length > max){
        showError(nombreInput, "El nombre tiene que estar entre 3 y 20");
    }else{
        showSuccess(nombreInput);
        valid = true;
    }
}

const showError = (input, message) => {
    // get the form-field element
    const formField = input.parentElement;
    // add the error class
    formField.classList.remove('success');
    formField.classList.add('error');

    // show the error message
    const error = formField.querySelector('small');
    error.textContent = message;
};

const showSuccess = (input) => {
    // get the form-field element
    const formField = input.parentElement;

    // remove the error class
    formField.classList.remove('error');
    formField.classList.add('success');

    // hide the error message
    const error = formField.querySelector('small');
    error.textContent = '';
}

form.addEventListener('submit', function (e) {
    // prevent the form from submitting
    e.preventDefault();

    // validate fields
    let isCheckNameValid = checkName();

    let isFormValid = isCheckNameValid;

    // submit to the server if the form is valid
    if (isFormValid) {
        e.submit()
        console.log("Formulario valido")
    }
});

form.addEventListener('input', function (e) {
    switch (e.target.id) {
        case 'nombre':
            checkName();
            break;
        case 'apellido':
            checkName();
            break;
    }
});
